"use client";

export default function Header(){
return (
    <div className="flex justify-between items-center p-4  bg-white border-b border-gray-300">
     <h2><b>WHATBYTES</b></h2>
     <h2>Suraj Ali</h2>

    </div>
)
}